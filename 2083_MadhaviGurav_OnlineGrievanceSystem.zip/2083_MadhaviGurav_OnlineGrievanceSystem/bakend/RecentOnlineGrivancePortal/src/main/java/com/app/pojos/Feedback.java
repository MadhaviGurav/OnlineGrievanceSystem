package com.app.pojos;


import javax.persistence.Entity;
import javax.persistence.*;
import javax.persistence.ManyToOne;
import static javax.persistence.GenerationType.IDENTITY;

import java.sql.Date;

import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;



    @Entity
    @Table(name="feedback")
    public class Feedback{
	
	@Id
	@GeneratedValue(strategy = IDENTITY)
    @Column(name = "id", unique = true, nullable = false)
	private Integer id;
	
	private String name;
	private String email;
	private String feedback;
	private Date date;
	
	
	@ManyToOne()
	@JoinColumn(name = "complaintId")
	private Complaint complaint;
	
	public Feedback() {
		super();
	}

	
	public Feedback(Integer id, String name, String email, String feedback, Date date, Complaint compl) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.feedback = feedback;
		this.date = date;
		this.complaint = compl;
	}


	
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	

	public Complaint getComplaint() {
		return complaint;
	}


	public void setComplaint(Complaint complaint) {
		this.complaint = complaint;
	}


	public void setDate(Date date) {
		this.date = date;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	
	public Date getDate() {
		return date;
	}

	public void setData(Date data) {
		this.date = data;
	}

	@Override
	public String toString() {
		return "Feedback [id=" + id + ", name=" + name + ", email=" + email + ", feedback=" + feedback + ", data="
				+ date + ", compl=" + complaint + "]";
	}

	
	
	
	
	

}
