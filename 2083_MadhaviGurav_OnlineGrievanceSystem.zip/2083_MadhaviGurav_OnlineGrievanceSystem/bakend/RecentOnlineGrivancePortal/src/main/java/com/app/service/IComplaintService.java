package com.app.service;

import java.util.List;
import java.util.Set;

import javax.validation.Valid;

import com.app.dto.ComplaintRegDto;
import com.app.pojos.Complaint;

public interface IComplaintService {

	Complaint registerComplaint(@Valid ComplaintRegDto complaintRegDto);

	Complaint deleteComplaint(int cid);

	Complaint updateComplaint(int cid, Complaint complaint);

	Set<Complaint> getAllComplaints();

	Complaint registerComplaint(Complaint c);

	
	//Complaint getComplaint(long parseLong);

	//Complaint getComplaint(long complaintId);

	//Complaint updateComplaint(Complaint complaint);

	//void deleteComplaint(long parseLong);





	

	



	
	
	
}
