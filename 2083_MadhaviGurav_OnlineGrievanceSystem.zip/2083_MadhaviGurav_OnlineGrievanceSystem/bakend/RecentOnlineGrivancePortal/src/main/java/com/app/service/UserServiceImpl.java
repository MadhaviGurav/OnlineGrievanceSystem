package com.app.service;


import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.*;
import com.app.exception.UserException;
import com.app.model.*;
import com.app.pojos.*;
@Service
@Transactional
public class UserServiceImpl implements IUserService{

@Autowired    
	private UserRepository userRepository;
@Autowired
    private RoleRepository roleRepository;
@Autowired
private EntityManager mgr;

    public UserServiceImpl() {
      
        System.out.println("in userserviceImpl ctr");
    }
    
    /** Create a new User */
    public User createUser(User model) {
        User user = new User();
        if (userRepository.findByEmail(model.getEmail()).isPresent()) {
            return null;
        } else {
            
            user.setName(model.getName());            
            user.setEmail(model.getEmail());
            user.setPassword(model.getPassword());
            user.setRoles(model.getRoles());
            User savedUser = userRepository.save(user);
            return user;
              
        }
    }

    /** Update an Existing User */

    public User updateUser(int id,User user) {
        if(userRepository.findById(id).isPresent()) {
            User newUser = userRepository.findById(id).get();
           
            newUser.setName(user.getName());
            
            newUser.setEmail(user.getEmail());
            newUser.setRoles(user.getRoles());
            User savedUser = userRepository.save(newUser);
            return newUser;
            
        }
        return null;
       
    }
    
    /** Delete an User*/
    public User deleteUser(int id) {
        if (userRepository.findById(id).isPresent()) {
            userRepository.deleteById(id);
            if (userRepository.findById(id).isPresent())
                return null;
            
        }  return null;
    }

    public UserModel getUser(int id) {
        if(userRepository.findById(id).isPresent()) {
            User user = userRepository.findById(id).get();
            UserModel userModel = new UserModel();
            
            userModel.setName(user.getName());
            userModel.setEmail(user.getEmail());
            userModel.setPassword(user.getPassword());
            userModel.setRoles( getRoleSet(user));
            return userModel;
        } else return null;
    }
//    public Set<UserModel> getUsers() {
//        Set<User> userSet = (Set<User>) userRepository.findAll();
//        if(userSet.size()>0) {
//            Set<UserModel> userModels = new HashSet<>();
//            for (User user : userSet) {
//                UserModel model = new UserModel();
//                
//                model.setName(user.getName());
//               
//                model.setEmail(user.getEmail());
//                model.setPassword(user.getPassword());
//                model.setRoles(getRoleSet(user));
//                userModels.add(model);
//            }
//            return userModels;
//        } else return new HashSet<UserModel>();
//    }
    private Set<RoleModel> getRoleSet(User user){
        Set<RoleModel> roleSet = new HashSet<>();
       // for(int i=0; i< user.getRoles().size(); i++) {
        roleSet.forEach( role->{ 
        RoleModel roleModel = new RoleModel();
			/*
			 * roleModel.setName(user.getRoles().forEach(users->user.getName()));
			 * roleModel.setDescription(user.getRoles().get(i).getDescription());
			 */
            roleModel.setName(role.getName());
          //  roleModel.setDescription(role.getDescription());
            roleSet.add(roleModel);
        });
        return roleSet;
    }

    @Override
	public Set<UserModel> getUsers() {
		// TODO Auto-generated method stub
		
		return new HashSet(userRepository.findAll());
	}
//    @Override
//	public User authenticateUser(User n) {
//		// TODO Auto-generated method stub
//		System.out.println("in service meth");
//		String jpql = "select u from user_t u where u.email=:email and u.password=:pass";
//		 return mgr.unwrap(Session.class).createQuery(jpql,User.class)
//				 .setParameter("email", n.getEmail())
//				 .setParameter("pass", n.getPassword())
//				 .getSingleResult();  
//	}

    @Override
	public User authenticateUser(String email,String password ) {
		// TODO Auto-generated method stub
		System.out.println("in login service meth Email: "+email+" Password: "+password);
		return userRepository.loginNgo(email, password);
	}
	

	
}


