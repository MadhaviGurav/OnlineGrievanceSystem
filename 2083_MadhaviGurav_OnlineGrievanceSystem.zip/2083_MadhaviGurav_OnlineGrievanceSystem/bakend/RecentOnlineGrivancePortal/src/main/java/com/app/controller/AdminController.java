//package com.app.controller;
//
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//
//
//import com.app.pojos.*;
//
//import com.app.service.*;
//
//@Controller
//@RequestMapping("/Admin")
//public class AdminController {
//	
//	
//	@Autowired
//	private IUserService userService;
//
//
//
//	public AdminController() {
//		System.out.println("In register admin Controller");
//	}
//
//
//	//add user
//
//		@GetMapping("/addUser")
//			public String addStaff(){
//			System.out.println("In register add user Controller");
//			return "addUser";
//			}
//		
//		@PostMapping("/addUser")
//			public ResponseEntity<?>addNewUser(@RequestBody User user)
//			{
//				System.out.println("in add user"+user);
//				try {
//					return new ResponseEntity<>(userService.addNewUser(user),HttpStatus.OK);
//				}
//				catch(RuntimeException e){
//					return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
//					
//				}
//
//			}
//
//
//
//
//	//update user data
//
//	@PutMapping("/updateUser")
//	public String updateUser(){
//		System.out.println("In register user admin Controller");
//		return "updateUser";
//	}
//
//
//	@PutMapping("/updateUser/{prn}")
//	public ResponseEntity<?>updateUser(@PathVariable int cid,@RequestBody User user)
//	{
//		System.out.println("in put user"+user);
//		try {
//		return new ResponseEntity<>(userService.updateUser(cid,user),HttpStatus.OK);
//		}
//		catch(RuntimeException e){
//			return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
//			
//		}
//	}
//
//
//
//	//delete user
//
//	@GetMapping("/deleteUser")
//	public String deleteUser(){
//		System.out.println("In register user admin Controller");
//		return "deleteUser";
//	}
//
//	@DeleteMapping("/deleteUser/{prn}")
//	public ResponseEntity<?>deleteUser(@PathVariable int cid)
//	{
//		System.out.println("in delete user");
//		try {
//		return new ResponseEntity<>(userService.deleteUser(cid),HttpStatus.OK);
//		}
//		catch(RuntimeException e){
//			return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
//			
//		}
//	}
//
//
//	}
//
//		
//
//
//
//
//
