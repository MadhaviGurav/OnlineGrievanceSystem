package com.app.dao;

import javax.validation.Valid;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.dto.ComplaintRegDto;
import com.app.pojos.Complaint;

public interface ComplaintRepository extends JpaRepository<Complaint, Integer>
{

	Complaint save(@Valid ComplaintRegDto complaintRegDto);

}
