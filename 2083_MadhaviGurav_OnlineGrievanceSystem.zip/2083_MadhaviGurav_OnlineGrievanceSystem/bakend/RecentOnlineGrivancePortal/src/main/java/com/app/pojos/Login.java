//package com.app.pojos;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//
//import javax.persistence.OneToOne;
//import javax.persistence.Table;
//
//@Entity
//@Table(name="login")
//public class Login {
//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	@Column(length = 20,unique = true)
//	private int prn;
//	@Column(length = 20,nullable=false)
//	private String password;
//	
//	
//	@OneToOne
//	private User emp;
//	
//	public Login() {
//		super();
//	}
//
//	public Login(int prn, String password, User emp) {
//		super();
//		this.prn = prn;
//		this.password = password;
//	
//		this.emp = emp;
//	}
//
//	public int getPrn() {
//		return prn;
//	}
//
//	public void setPrn(int prn) {
//		this.prn = prn;
//	}
//
//	public String getPassword() {
//		return password;
//	}
//
//	public void setPassword(String password) {
//		this.password = password;
//	}
//
//	
//
//	public User getEmp() {
//		return emp;
//	}
//
//	public void setEmp(User emp) {
//		this.emp = emp;
//	}
//
//	@Override
//	public String toString() {
//		return "Login [prn=" + prn + ", password=" + password + ", emp=" + emp + "]";
//	}
//	
//	
//	
//	
//
//
//}
