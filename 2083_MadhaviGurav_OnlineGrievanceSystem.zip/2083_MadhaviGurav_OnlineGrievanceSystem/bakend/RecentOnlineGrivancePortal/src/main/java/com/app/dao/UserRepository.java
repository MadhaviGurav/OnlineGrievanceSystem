package com.app.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.app.pojos.User;
@Repository
public interface UserRepository extends JpaRepository<User,Integer>{


    Optional<User> findByEmail(String email);

	//User loginUser(String email, String password);

	/*
	 * @Query(value = "select * from user_t", nativeQuery = true) List<User>
	 * findById();
	 */


	
	@Query("select u from User u where u.email=:email and u.password=:password")
	   User loginNgo(@Param("email") String email, @Param("password") String password);
}


