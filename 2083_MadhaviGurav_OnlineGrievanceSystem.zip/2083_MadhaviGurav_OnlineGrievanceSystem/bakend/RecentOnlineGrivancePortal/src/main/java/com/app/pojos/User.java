package com.app.pojos;


import java.util.HashSet;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "user_t")
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Column(length = 20)
	private String name;
	
	@Column(length = 20,unique =true)
	private String email;
	
	@Column(length = 20,nullable = false)
	private String password;
	
	
	//private String course;
	@JsonIgnoreProperties("users")
	@ManyToMany(cascade = {CascadeType.MERGE,CascadeType.PERSIST})
	@Fetch(FetchMode.JOIN)
	@JoinTable(
			name="user_role",
			joinColumns = @JoinColumn(name="USER_ID",referencedColumnName = "id"),
			inverseJoinColumns=@JoinColumn(name="ROLE_ID",referencedColumnName = "id"))
	private Set<Role>roles=new HashSet<>();
	@JsonIgnore
	//@OnDelete(action = OnDeleteAction.NO_ACTION)
	@OneToMany(mappedBy = "complaintOwner",cascade=CascadeType.ALL,orphanRemoval = true,fetch = FetchType.EAGER)
	@Fetch(FetchMode.JOIN)
	private Set<Complaint> complaintSet=new HashSet<>();
	
	public User() {
		System.out.println("in user ctor");
	}

	
	
	public User(/*Integer id,*/ String name, String email, String password, Set<Role> roles, Set<Complaint> complaintSet) {
		super();
		//this.id = id;
		this.name = name;
		this.email = email;
		this.password = password;
		this.roles = roles;
		this.complaintSet = complaintSet;
	}

	
 public User(String email, String password) {
		super();
		this.email = email;
		this.password = password;
	}



public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	

	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Set<Role> getRoles() {
		return roles;
	}

	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}

	public Set<Complaint> getComplaintSet() {
		return complaintSet;
	}

	public void setComplaintSet(Set<Complaint> complaintSet) {
		this.complaintSet = complaintSet;
	}



	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", email=" + email + ", password=" + password + ", roles=" + roles
				+ ", complaintSet=" + complaintSet + "]";
	}

	 
	

	


	

	 
//
//	public List<Complaint> getComplaintList() {
//		return complaintList;
//	}
//
//	public void setComplaintList(List<Complaint> complaintList) {
//		this.complaintList = complaintList;
//	}

	 
	
	
	
	
}
