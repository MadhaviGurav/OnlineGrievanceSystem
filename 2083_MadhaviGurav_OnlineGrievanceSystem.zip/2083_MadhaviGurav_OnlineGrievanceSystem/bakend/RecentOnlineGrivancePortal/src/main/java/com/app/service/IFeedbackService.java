package com.app.service;

import java.util.List;
import java.util.Set;

import com.app.pojos.Feedback;

public interface IFeedbackService {

	Feedback createFeedback(Feedback f);

	Set<Feedback> getAllComplaints();

	

	

}
