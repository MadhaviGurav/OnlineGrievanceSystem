package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.*;
import com.app.pojos.*;
import com.app.service.*;

@RestController
@RequestMapping("/role")
@CrossOrigin
public class RoleController {
@Autowired
    private IRoleService roleService;
@Autowired
private RoleRepository roleRepository;


    public RoleController() {
    	System.out.println("in roleController");
     
    }

    @PostMapping("/create")
    public ResponseEntity<?> createRole(@RequestBody Role role) {
    	Role retrole =roleService.createRole(role);
    	return new ResponseEntity<Role>(retrole,HttpStatus.OK);
    }
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteRole(@PathVariable int id) {
    	Role retrole =roleService.deleteRole(id);
    	return new ResponseEntity<Role>(retrole,HttpStatus.OK);
        
    }
//    @GetMapping("/details/{id}")
//    public Role getRole(@PathVariable int id) {
//        if(roleRepository.findById(id).isPresent())
//            return roleRepository.findById(id).get();
//        else return null;
//    }
//    @GetMapping("/all")
//    public List<Role> getRoles() {
//        return roleRepository.findAll();
//    }
    @PutMapping("/updateRole/{id}")
    public ResponseEntity<?> updateRole(@PathVariable int id, @RequestBody Role role) {
    	
        Role retrole= roleService.updateRole(id, role);
        return new ResponseEntity<Role>(retrole,HttpStatus.OK);
   }



}