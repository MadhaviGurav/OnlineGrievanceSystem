package com.app.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.FeedbackRepository;
import com.app.dao.RoleRepository;
import com.app.pojos.Complaint;
import com.app.pojos.Feedback;
import com.app.pojos.User;
import com.app.service.IFeedbackService;


@RestController
@RequestMapping("/feedback")
@CrossOrigin(origins="http://localhost:3000")
public class FeedbackController {
	
	@Autowired
	private IFeedbackService feedbackService;
	@Autowired
	private FeedbackRepository feedbackRepository;

	public FeedbackController() {

		System.out.println("in FeedbackController ctr");
	}
	
	@PostMapping("/create")
	public ResponseEntity<?> createFeedback(@RequestBody Feedback feedback) {
		System.out.println("In post mapping of create");
		Feedback retfeedback = feedbackService.createFeedback(feedback);
		return new ResponseEntity<Feedback>(retfeedback, HttpStatus.OK);
	}
	@GetMapping("/all")
	public Set<Feedback> getAllFeedback() {
		System.out.println("in get all Feedback");
		return feedbackService.getAllComplaints();

	}
	
	

}
