package com.app.service;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.*;
import com.app.dto.ComplaintRegDto;
import com.app.exception.UserException;
import com.app.pojos.*;

@Service
@Transactional
public class ComplaintServiceImpl implements IComplaintService {
	
	@Autowired
	private  ComplaintRepository complaintDao; 
   

	
		
	@Override
	public Complaint registerComplaint(Complaint c) {
		//c.setComplaintOwner((User)hs.getAttribute("user"));
		
		return complaintDao.save(c);
		 }
		
	@Override
	 public Complaint deleteComplaint(int cid) {
		System.out.println("in delete complaint serviceimpl");
		Optional<Complaint>opCustomer=complaintDao.findById(cid);
		Complaint complaints=opCustomer.orElseThrow(()->new UserException("Invalid Id"));
		complaintDao.deleteById(cid);
		return (complaints);
		   }
		
		

		
	
		
		@Override
		public Complaint updateComplaint(int cid, Complaint complaint) {
			Optional<Complaint>opComplaint=complaintDao.findById(cid);
			Complaint complaints=opComplaint.orElseThrow(()->new UserException("Invalid Id"));
			
			return complaintDao.save(complaint);

		}

		@Override
		public Set<Complaint> getAllComplaints() {
			// TODO Auto-generated method stub
			
			return new HashSet(complaintDao.findAll());
		}

		@Override
		public Complaint registerComplaint(@Valid ComplaintRegDto complaintRegDto) {
			// TODO Auto-generated method stub
			return complaintDao.save(complaintRegDto);
		}

		
//		@Override
//		public Complaint getComplaint(long complaintId) {
//	   //list=new ArrayList<>();
//			Complaint c=null;
//			for(Complaint complaint : set) {
//				if(complaint.getId() == complaintId) {
//					c=complaint;
//					break;
//				}
//				
//			}
//			
//		return c;
//		}
		
//		@Override
//		public void deleteComplaint(long parseLong) {
//			list=this.list.stream().filter(e ->e.getId()!=parseLong).collect(Collectors.toList());
//			
//			
//		}
}

