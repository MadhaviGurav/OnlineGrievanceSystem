import React, { Component } from 'react'
import UserServices from '../Services/UserServices.js'
import { Link } from 'react-router-dom';

class StaffDashboardComponent extends Component {

    constructor(props) {
        super(props)
        this.state = {
            complaints: [],
          //  message: null
        }
         this.deleteComplaint = this.deleteComplaint.bind(this);
         //this.editComplaint = this.editComplaint.bind(this);
        // this.addComplaint = this.addComplaint.bind(this);
        // this.reloadComplaintList = this.reloadComplaintList.bind(this);
    }

    componentDidMount() {
        this.reloadComplaintList();
    }
    // componentDidMount(){
    //     UserServices.getUserById().then((res)=>{
    //         this.setState({complaints:res.data})
    //     });
    // }

    componentDidMount(){
        UserServices.getAllComplaints().then((res)=>{
            this.setState({complaints:res.data})
        });
    }
    reloadComplaintList() {
        UserServices.fetchComplaints()
            .then((res) => {
                this.setState({complaints: res.data.result})
                console.log(this.state.complaints);
            });
            // UserService.getUsers().then(resp => {
            //     this.setState({ users: resp.data });
            //     console.log(this.state.users);
            // })
    }

    deleteComplaint(id) {
        UserServices.deleteComplaint(id)
           .then(res => {
              
               this.setState({complaints: this.state.complaints.filter(complaint => complaint.id !== id)});
               window.localStorage.removeItem("complaintId");
            })

    }

    updateComplaint(id) {
        window.localStorage.setItem("complaintId", id);
        this.props.history.push('/edit-complaint');
    }

    addComplaint() {
        window.localStorage.removeItem("complaintId");
        this.props.history.push('/complaint');
    }
    
    render() {
        return (
            <div  className="col-md-10" style={{marginLeft: '20px'}}>
                <h2 className="text-center"> DashBoard</h2>
               <Link to="/complaint"><button className="btn btn-danger" style={{width:'200px'}} onClick={() => this.addComplaint()}> Register Complaint</button></Link>
               <Link to="/feedback"><button className="btn btn-danger" style={{width:'200px'}} onClick={() => this.addComplaint()} style={{marginLeft: '20px'}}> Feedback</button></Link>
               {/*} <Link to="/changePassword"><button className="btn btn-danger" style={{width:'200px'}} onClick={() => this.addComplaint()} style={{marginLeft: '20px'}}> Password</button></Link>*/}
                <Link to="/"><button className="btn btn-danger" style={{width:'200px'}} onClick={() => this.addComplaint()} style={{marginLeft: '560px'}}> Log Out</button></Link>
                <div className="row">
                <table className="table table-striped table-bordered">
                    <tbody>
                        <tr>
                            <th className="hidden">Id</th>
                            <th>Date</th>
                            <th>Complaint Type</th>
                            <th>Description</th>
                            
                            
                        </tr>
                    </tbody>
                    <tbody>
                        {
                            this.state.complaints.map(
                        complaints=>
                                    <tr key={complaints.id}>
                                        <td>{complaints.id}</td>
                                        <td>{complaints.date}</td>
                                        <td>{complaints.cptType}</td>
                                        <td>{complaints.cptDesc}</td>
                                       
                                      
                                        <td>
                                            <button onClick={() => this.deleteComplaint(complaints.id)} className="btn btn-danger"> Delete</button>
                                            <button onClick={() => this.editComplaint(complaints.id)} style={{marginLeft: '20px'}} className="btn btn-success"> Edit</button>
                                        </td> 
                                    </tr>
                            )
                        }
                    </tbody>
                    
                </table>

            </div>
            </div>
        );
    }

}

export default StaffDashboardComponent;