import React from 'react';
import { Card, Container, Jumbotron } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { Button, CardBody } from 'reactstrap';

const Admin = (props) => {
  return (
    <div>
      <Jumbotron className="text-center">
        <Card>
           <CardBody>
            <h1 className="text-center my-1">ADMIN</h1>
            <p>Welcome to Adminstrator</p>
        </CardBody>
        </Card>
        <hr/>
       <Container >
         
         
       <Link to="/student"><Button color="primary" size="lg" >STUDENT</Button>{' '}</Link>
       <hr/>
       <Link to="/staff"><Button color="primary" size="lg" >STAFF</Button>{' '}</Link>
       <hr/>
       {/*<Button color="primary" size="lg" >STAFF</Button>{' '}*/}
       <hr/>
       <Link to="/cordinator"><Button color="primary" size="lg" >CO-ORDINATOR</Button>{' '}</Link>
       <hr/>
       <Link to="/management"><Button color="primary" size="lg" >MANAGEMENT</Button>{' '}</Link>
       
      
    </Container>
    </Jumbotron>
    </div>
  );
}

export default Admin;
