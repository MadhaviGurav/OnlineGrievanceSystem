import React, { Component } from 'react'
import UserServices from '../Services/UserServices.js'
import { Link } from 'react-router-dom';
class StudentDeletion extends Component {
    constructor(props) {
        super(props)

        this.state = {
            id: '',
            user:[]
            
            
        }
        this.deleteUser = this.deleteUser.bind(this);
        // this.changeEmailIdHandler = this.changeEmailIdHandler.bind(this);
        // this.changePassworHandler = this.changePassworHandler.bind(this);
        this.submit = this.submit.bind(this);
      
    }
    // changeEmailIdHandler = (event) => {
    //     this.setState({ emailId: event.target.value });
    // }
    // changePassworHandler = (event) => {
    //     this.setState({ password: event.target.value });
    // }
    
    deleteUser(userId) {
        UserServices.deleteUser(userId)
           .then(res => {
               if(res.data!=null)
               alert("user deleted successfully");
               this.setState({users: this.state.users.filter(user => user.id !== userId)});
           })

    }
    submit = (e) => {
        e.preventDefault()
        let loginDetails = { id: this.state.id}
        console.log('User => ' + JSON.stringify(loginDetails))
       let validatedUser= UserServices.loginUser(loginDetails).then(res => {
            this.props.history.push('/changePassword');
            alert('Login  have been successfully registered.');
            console.log(validatedUser);
        });

    }
    onChange = (e) =>
        this.setState({ [e.target.name]: e.target.value });

    

   
    render() {
        return (
            <div>
                <div>
                    <div className="container">
                        <div className="row">
                            <div className="card col-md-6 offset-md-3 offset-md-3">
                                <h3 className="text-center">Student Deletion</h3>
                                <div className="card-body">
                                    <form>
                                    <div className="form-group">
                                            <label>Student's id: </label>
                                            <input placeholder="id" name="id" className="form-control" value={this.state.id} onChange={this.onChange} required />
                                        </div>
                                        <button className="btn btn-success" onClick={this.loginUser} >Submit</button>
                                        {/* <button className="btn btn-success" onClick={() => this.deleteUser(id)}> Delete</button> */}
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default StudentDeletion
