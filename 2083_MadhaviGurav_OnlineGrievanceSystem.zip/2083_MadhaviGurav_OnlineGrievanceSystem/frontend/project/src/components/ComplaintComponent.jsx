import React, { Component } from 'react'
import UserServices from '../Services/UserServices.js'
import { Link } from 'react-router-dom';
import Date from '../components/Date';
class ComplaintComponent extends Component {

    constructor(props) {
        super(props);
        this.state = {

            cptDesc: '',
            cptType: '',
            date: '',

            complaintOwner: { id:2}
                
   
           
        }
        this.saveComplaint = this.saveComplaint.bind(this);
    }

    saveComplaint = (e) => {
        e.preventDefault();
        let complaint = {
            cptDesc: this.state.cptDesc, cptType: this.state.cptType,
            date: this.state.date, complaintOwner: this.state.complaintOwner,
        };
        console.log(JSON.stringify(complaint))
        UserServices.addComplaint(complaint)
            .then(res => {
                this.setState({ message: 'complaint added successfully.' });
                this.props.history.push('/staffDash');
            });
    }

    onChange = (e) =>
        this.setState({ [e.target.name]: e.target.value });

    render() {
        return (
            <div>
                <div>
                    <div className="container">
                        <div className="row">
                            <div className="card col-md-6 offset-md-3 offset-md-3">
                                <h3 className="text-center"> Complaint Form</h3>
                                <div className="card-body">
                                    <form>


                                        <div className="form-group">
                                            <label>Complaint Type</label>
                                            <input type="text" placeholder="cptType" name="cptType" className="form-control" value={this.state.cptType} onChange={this.onChange} />
                                        </div>

                                        <div className="form-group">
                                            <label>Write Complaint:</label>
                                            <input type="cptDesc" placeholder="cptDesc" name="cptDesc" className="form-control" value={this.state.cptDesc} onChange={this.onChange} />
                                        </div>
                                        <div className="form-group">
                                            <label>Date</label>
                                             <input type="date" placeholder="Date" name="date" className="form-control" value={this.state.date} onChange={this.onChange} />
                                        </div>

                                            {/* <Date/>
                                            </div> */}
                                       


                                        <button className="btn btn-success" onClick={this.saveComplaint}>Submit</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default ComplaintComponent;