import React, { Component } from 'react'
import { CardBody,Card } from 'reactstrap';
import UserServices from "../Services/UserServices";

class UpdateStudent extends Component {

    constructor(props){
        super(props);
        this.state ={
            id:'',
           name: '',
           email:''
            
        }
        this.saveUser = this.saveUser.bind(this);
        this.loadUser = this.loadUser.bind(this);
    }

    componentDidMount() {
        this.loadUser();
    }

    loadUser() {
        UserServices.getUserById(window.localStorage.getItem("id"))
            .then((res) => {
                let user = res.data.result;
                this.setState({
                                name:user.name,
                                email:user.email
                })
            });
    }

    onChange = (e) =>
        this.setState({ [e.target.name]: e.target.value });

    saveUser = (e) => {
        e.preventDefault();
         let user = {id: this.state.id,name: this.state.name,email: this.state.email
             };
        UserServices.updateUser(user)
            .then(res => {
                this.setState({message : 'User updated successfully.'});
                this.props.history.push('/child_list_view');
            });
    }

    render() {
        return (
            <div className="register-user">
                <div className="card col-md-6 offset-md-3 offset-md-3">
                 <h2 className="text-center">Update User</h2>
                <form>
                    <CardBody>
                    <div className="form-group">
                        <label>Id</label>
                        <input type="number" placeholder="Id" name="id" className="form-control" value={this.state.id} onChange={this.onChange}/>
                    </div>

                    <div className="form-group">
                        <label>Name</label>
                        <input type=" Name" placeholder="Name" name="name" className="form-control" value={this.state.name} onChange={this.onChange}/>
                    </div>

                    <div className="form-group">
                        <label>Email</label>
                        <input type="email" placeholder="Email" name="email" className="form-control" value={this.state.email} onChange={this.onChange}/>
                    </div>

                   <button className="btn btn-success" onClick={this.saveUser}>Save</button>
                </CardBody>
                </form>
                </div>
            </div>
        );
    }
}  

export default UpdateStudent;