import React, { Component } from 'react'
import UserServices from '../Services/UserServices.js'
import { Link } from 'react-router-dom';
class CordinatorDeletion extends Component {
    constructor(props) {
        super(props)

        this.state = {
            newPassword: ''
            
        }

        // this.changeEmailIdHandler = this.changeEmailIdHandler.bind(this);
        // this.changePassworHandler = this.changePassworHandler.bind(this);
        this.submit = this.submit.bind(this);
      
    }
    // changeEmailIdHandler = (event) => {
    //     this.setState({ emailId: event.target.value });
    // }
    // changePassworHandler = (event) => {
    //     this.setState({ password: event.target.value });
    // }

    submit = (e) => {
        e.preventDefault()
        let loginDetails = { newPassword: this.state.newPassword, confirmPassword: this.state.confirmPassword }
        console.log('User => ' + JSON.stringify(loginDetails))
       let validatedUser= UserServices.loginUser(loginDetails).then(res => {
            this.props.history.push('/changePassword');
            alert('Login  have been successfully registered.');
            console.log(validatedUser);
        });

    }
    onChange = (e) =>
        this.setState({ [e.target.name]: e.target.value });

    

   
    render() {
        return (
            <div>
                <div>
                    <div className="container">
                        <div className="row">
                            <div className="card col-md-6 offset-md-3 offset-md-3">
                                <h3 className="text-center">Coordinator Deletion</h3>
                                <div className="card-body">
                                    <form>
                                    <div className="form-group">
                                            <label>Coordinator's PRN: </label>
                                            <input placeholder="PRN" name="prn" className="form-control" value={this.state.prn} onChange={this.onChange} required />
                                        </div>
                                        <button className="btn btn-success" onClick={this.loginUser} >Submit</button>
                                       
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default CordinatorDeletion
